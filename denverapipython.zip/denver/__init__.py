'''
Denver is a project targeting python developers for easy and fast development
with the modules provided within it.
'''

#  Copyright (c) 2020 Xcodz.
#  All Rights Reserved.

__author__ = 'Xcodz'
__version__ = '2020.6.4'
