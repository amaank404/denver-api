import playsound


def play_sound(sound_file):
    playsound.playsound(sound_file)
